"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Users,
  CreditCard,
  Package,
  Truck,
  AlertTriangle,
  FileText,
  ClipboardList,
  MessageSquare,
} from "lucide-react";

interface SidebarProps {
  className?: string;
}

const navItems = [
  {
    title: "Dashboard",
    href: "/admin",
    icon: LayoutDashboard,
  },
  {
    title: "Miembros",
    href: "/admin/members",
    icon: Users,
  },
  {
    title: "Pagos",
    href: "/admin/payments",
    icon: CreditCard,
  },
  {
    title: "Kits",
    href: "/admin/kits",
    icon: Package,
  },
  {
    title: "Envíos",
    href: "/admin/shipments",
    icon: Truck,
  },
  {
    title: "Incidencias",
    href: "/admin/incidents",
    icon: AlertTriangle,
  },
  {
    title: "Plantillas",
    href: "/admin/templates",
    icon: MessageSquare,
  },
  {
    title: "Actividad",
    href: "/admin/activity",
    icon: ClipboardList,
  },
  {
    title: "Reportes",
    href: "/admin/reports",
    icon: FileText,
  },
];

export function Sidebar({ className }: SidebarProps) {
  const pathname = usePathname();

  return (
    <div className={cn("pb-12 w-64 bg-white border-r min-h-screen", className)}>
      <div className="space-y-4 py-4">
        <div className="px-4 py-2">
          <Link href="/admin" className="flex items-center gap-2">
            <span className="text-xl font-serif font-bold">KingClub</span>
            <span className="text-xs bg-black text-white px-2 py-0.5 rounded">
              Admin
            </span>
          </Link>
        </div>
        <nav className="space-y-1 px-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.href || pathname?.startsWith(`${item.href}/`);

            return (
              <Link
                key={item.href}
                href={item.href as any}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                  isActive
                    ? "bg-black text-white"
                    : "text-gray-600 hover:bg-gray-100 hover:text-gray-900"
                )}
              >
                <Icon className="h-4 w-4" />
                {item.title}
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
