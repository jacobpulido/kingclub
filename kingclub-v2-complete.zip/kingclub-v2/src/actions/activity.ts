"use server";

import { createClient } from "@/lib/supabase/server";
import { requireAdmin } from "@/lib/system/admin";
import {
  getActivityLogs,
  getEntityLogs,
  getRecentActivity,
  getActivityStats,
  type LogFilter,
  type EntityType,
  type LogAction,
  type ActivityLog,
} from "@/lib/system/logger";
import {
  successResponse,
  errorResponse,
  paginatedSuccessResponse,
} from "@/lib/system/responses";

export interface ActivityFilter {
  entity_type?: EntityType;
  entity_id?: string;
  action?: LogAction;
  user_id?: string;
  date_from?: string;
  date_to?: string;
  page?: number;
  limit?: number;
}

/**
 * Get activity logs with pagination
 */
export async function getActivities(filter: ActivityFilter = {}) {
  await requireAdmin();

  try {
    const page = filter.page || 1;
    const limit = filter.limit || 50;
    const offset = (page - 1) * limit;

    const logFilter: LogFilter = {
      entity_type: filter.entity_type,
      entity_id: filter.entity_id,
      action: filter.action,
      user_id: filter.user_id,
      date_from: filter.date_from,
      date_to: filter.date_to,
      limit,
      offset,
    };

    const { data, count } = await getActivityLogs(logFilter);

    return paginatedSuccessResponse(data, page, limit, count);
  } catch (error) {
    console.error("Error getting activities:", error);
    return errorResponse("Error al obtener actividades");
  }
}

/**
 * Get activity logs for a specific entity
 */
export async function getEntityActivity(
  entityType: EntityType,
  entityId: string,
  limit: number = 20
) {
  await requireAdmin();

  try {
    const logs = await getEntityLogs(entityType, entityId, limit);
    return successResponse(logs);
  } catch (error) {
    console.error("Error getting entity activity:", error);
    return errorResponse("Error al obtener actividad de la entidad");
  }
}

/**
 * Get recent activity for dashboard
 */
export async function getDashboardActivity(limit: number = 10) {
  await requireAdmin();

  try {
    const logs = await getRecentActivity(limit);
    return successResponse(logs);
  } catch (error) {
    console.error("Error getting dashboard activity:", error);
    return errorResponse("Error al obtener actividad reciente");
  }
}

/**
 * Get activity statistics
 */
export async function getActivityReport(
  dateFrom?: string,
  dateTo?: string
) {
  await requireAdmin();

  try {
    const stats = await getActivityStats(dateFrom, dateTo);
    return successResponse(stats);
  } catch (error) {
    console.error("Error getting activity stats:", error);
    return errorResponse("Error al obtener estadísticas de actividad");
  }
}

/**
 * Get unique entity types for filter
 */
export async function getEntityTypes() {
  await requireAdmin();
  const supabase = await createClient();

  try {
    const { data, error } = await supabase
      .from("activity_logs")
      .select("entity_type")
      .order("entity_type");

    if (error) throw error;

    // Get unique values
    const uniqueTypes = [...new Set(data?.map((d) => d.entity_type) || [])];

    return successResponse(uniqueTypes);
  } catch (error) {
    console.error("Error getting entity types:", error);
    return errorResponse("Error al obtener tipos de entidad");
  }
}

/**
 * Get unique actions for filter
 */
export async function getActionTypes() {
  await requireAdmin();
  const supabase = await createClient();

  try {
    const { data, error } = await supabase
      .from("activity_logs")
      .select("action")
      .order("action");

    if (error) throw error;

    // Get unique values
    const uniqueActions = [...new Set(data?.map((d) => d.action) || [])];

    return successResponse(uniqueActions);
  } catch (error) {
    console.error("Error getting action types:", error);
    return errorResponse("Error al obtener tipos de acción");
  }
}

/**
 * Get activity timeline for a user
 */
export async function getUserActivity(
  userId: string,
  limit: number = 50
) {
  await requireAdmin();

  try {
    const filter: LogFilter = {
      user_id: userId,
      limit,
    };

    const { data, count } = await getActivityLogs(filter);

    return paginatedSuccessResponse(data, 1, limit, count);
  } catch (error) {
    console.error("Error getting user activity:", error);
    return errorResponse("Error al obtener actividad del usuario");
  }
}

/**
 * Search activity logs
 */
export async function searchActivities(
  searchTerm: string,
  page: number = 1,
  limit: number = 50
) {
  await requireAdmin();
  const supabase = await createClient();

  try {
    const offset = (page - 1) * limit;

    const { data, error, count } = await supabase
      .from("activity_logs")
      .select("*, profiles:user_id(email, full_name)", { count: "exact" })
      .or(
        `description.ilike.%${searchTerm}%,action.ilike.%${searchTerm}%,entity_type.ilike.%${searchTerm}%`
      )
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) throw error;

    // Transform data
    const transformedData: ActivityLog[] = (data || []).map((log) => ({
      ...log,
      user_email: log.profiles?.email || null,
      user_full_name: log.profiles?.full_name || null,
    }));

    return paginatedSuccessResponse(transformedData, page, limit, count || 0);
  } catch (error) {
    console.error("Error searching activities:", error);
    return errorResponse("Error al buscar actividades");
  }
}
